import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from  'redux';
import * as sellerActions from 'store/modules/seller';



class sample extends Component {

//함수입니다.
//리듀서 사용법.
// SellerActions.리듀서이름
//SellerActions.getSellersList(category);

  render() {
    // const {.... } = thie.props;  =>  connect한 state를 설정 
    // const { 함수 } = this 
    return (
      <div>
        {/* <Edit
          ... = { ... or 함수}
        /> */}
      </div>
    );
  }
}

export default connect((state) => ({
 //module -> initialState
 //categories : state.seller.get('categories'),

}),
(dispatch) => ({
  

  //SellerActions : bindActionCreators(sellerActions,dispatch),

})
)(sample);